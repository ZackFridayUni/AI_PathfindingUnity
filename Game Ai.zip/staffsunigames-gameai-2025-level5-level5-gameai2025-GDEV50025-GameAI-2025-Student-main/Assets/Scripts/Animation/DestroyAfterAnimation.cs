using UnityEngine;

public class DestroyAfterAnimation : MonoBehaviour
{
    public void destroy()
    {
       Destroy(gameObject);
    }
}
