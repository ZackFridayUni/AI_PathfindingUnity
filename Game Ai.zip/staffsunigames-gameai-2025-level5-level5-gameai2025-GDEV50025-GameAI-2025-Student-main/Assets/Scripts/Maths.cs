using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Maths
{
    public static float Magnitude(Vector2 a)
    {
        //replace with correct formula 
        return 0.0f;
    }

    public static Vector2 Normalise(Vector2 a)
    {
        //replace with correct formula 
        return Vector2.zero;
    }

    public static float Dot(Vector2 lhs, Vector2 rhs)
    {
        //replace with correct formula 
        return 0.0f;
    }

    /// <summary>
    /// Returns the radians of the angle between two vectors
    /// </summary>
    public static float Angle(Vector2 lhs, Vector2 rhs)
    {
        //replace with correct formula 
        return 0.0f;
    }

    /// <summary>
    /// Translates a vector by X angle in degrees
    /// </summary>
    public static Vector2 RotateVector(Vector2 vector, float degrees)
    {
        //replace with correct formula 
        return Vector2.zero;
    }
}
